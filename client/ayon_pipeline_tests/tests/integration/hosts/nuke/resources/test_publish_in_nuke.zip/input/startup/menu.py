import nuke
import pyblish.util
import os

from ayon_core.lib import Logger

log = Logger().get_logger(__name__)


def test_publish():
	if os.environ.get("CLOSE_NUKE"):
		return

	log.debug("started publish")
	log_lines = []
	for result in pyblish.util.publish_iter():
		for record in result["records"]:
			log_lines.append("{}: {}".format(
				result["plugin"].label, record.msg))

		if result["error"]:
			err_fmt = "Failed {plugin.__name__}: {error} -- {error.traceback}"
			log.error(err_fmt.format(**result))
	log.debug("finished publish")
	log.info("stdout of publish {}".format("\n".join(log_lines)))

	os.environ["CLOSE_NUKE"] = "1"
	nuke.scriptExit()

nuke.addOnScriptLoad(test_publish)

