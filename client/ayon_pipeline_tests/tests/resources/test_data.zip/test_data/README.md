Test data
---------
Each class implementing `TestCase` can provide test file(s) by adding them to
	TEST_FILES = [('GDRIVE_FILE_ID', 'ACTUAL_FILE_NAME', 'MD5HASH')]

GDRIVE_FILE_ID can be pulled from shareable link from Google Drive app.

OR adding test resources as zip:
    TEST_FILES = [
        ("resources/test_publish_in_photoshop_auto_image.zip",
         "test_publish_in_photoshop_auto_image.zip", "")
    ]

OR adding unzipped folder: (relative path to test class)
    TEST_FILES = [
        ("test_publish_in_maya", "", "")
    ]


Currently it is expected that test file will be zip file with structure:
- expected - expected files (not implemented yet)
- input
    - data - test data (workfiles, images etc)
    - dumps - folder for json dump from AYON
	- easiest to run in your `ayon-docker` folder: `.manage.ps1 dump testproject`
	- any changes to Settings should be in "production" variant
    - env_vars 
        env_vars.json - dictionary with environment variables {key:value}
    - startup - scripts that should run in the host on its startup
